@echo off
chcp 65001 >nul
title KotikRelay - обновление на сервере (Котик 2.2)
net session >nul 2>&1
if errorlevel 1 (
  echo Запустите этот файл от имени администратора:
  echo правый клик по файлу -^> "Запуск от имени администратора".
  echo.
  pause
  exit /b 1
)

echo [1/4] Останавливаю все старые KotikRelay...
schtasks /End /TN "KotikRelay" >nul 2>&1
taskkill /IM KotikRelay.exe /F >nul 2>&1
timeout /t 3 >nul
tasklist /FI "IMAGENAME eq KotikRelay.exe" | find /I "KotikRelay.exe" >nul
if not errorlevel 1 (
  echo   ВНИМАНИЕ: старый KotikRelay не закрылся. Перезагрузите сервер и запустите этот файл снова.
  pause
  exit /b 1
)

echo [2/4] Копирую новые файлы в C:\1 ...
if not exist "C:\1" mkdir "C:\1"
if not exist "C:\1\updates" mkdir "C:\1\updates"
copy /Y "%~dp0KotikRelay.exe" "C:\1\KotikRelay.exe" >nul || goto copyfail
if exist "%~dp0admin.key" copy /Y "%~dp0admin.key" "C:\1\admin.key" >nul
copy /Y "%~dp0updates\android.txt" "C:\1\updates\android.txt" >nul || goto copyfail
copy /Y "%~dp0updates\Kotik.apk"   "C:\1\updates\Kotik.apk"   >nul || goto copyfail
copy /Y "%~dp0updates\pc.txt"      "C:\1\updates\pc.txt"      >nul || goto copyfail
copy /Y "%~dp0updates\Kotik.exe"   "C:\1\updates\Kotik.exe"   >nul || goto copyfail

echo [3/4] Запускаю новый KotikRelay из C:\1 (порты + автозапуск)...
"C:\1\KotikRelay.exe" --install
timeout /t 4 >nul

echo [4/4] Проверяю...
set OK=1
curl -s -o nul -w "%%{http_code}" http://localhost:47251/admin/cmd > "%TEMP%\kr_admin.txt" 2>nul
set /p CODE=<"%TEMP%\kr_admin.txt"
if "%CODE%"=="403" (
  echo   ✓ Новый сервер 2.2 работает: список игроков и команды Админки.
) else (
  echo   ✗ /admin/cmd ответил "%CODE%" ^(ждали 403^). Значит, работает не тот KotikRelay.
  set OK=0
)
curl -s http://localhost:47251/android.txt | find "name=2.2" >nul
if errorlevel 1 (
  echo   ✗ Обновление для телефона не 2.2.
  set OK=0
) else (
  echo   ✓ Раздаёт Котика 2.2 — старые Котики обновятся, а дальше будут брать обновления с GitHub.
)
if not exist "C:\1\admin.key" echo   ! Нет C:\1\admin.key — сервер создал свой ключ. Скопируйте его в %%APPDATA%%\Kotik\admin.key на ПК с Админкой.
echo.
if "%OK%"=="1" (echo Готово!) else (echo Что-то не так — пришлите Claude журнал C:\1\kotik-relay.log)
pause
exit /b 0

:copyfail
echo   Не удалось скопировать файлы в C:\1. Проверьте, что этот файл лежит рядом с KotikRelay.exe и папкой updates.
pause
exit /b 1
